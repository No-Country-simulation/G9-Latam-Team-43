# Evidencia técnica de integración OCI

## Servicios OCI usados
1. OCI Object Storage para almacenar artefactos `.joblib` y dataset.
2. OCI Compute para desplegar la API FastAPI.

## Comandos de referencia
```bash
oci os object put --bucket-name techmind-models --file models/modelo_categoria_macro.joblib
oci os object put --bucket-name techmind-models --file models/modelo_categoria_nlp.joblib
oci os object put --bucket-name techmind-models --file models/vectorizador_recomendador.joblib
oci os object put --bucket-name techmind-models --file models/matriz_recomendador.joblib
oci os object put --bucket-name techmind-models --file models/base_contenidos.joblib

podman build -t techmind-api:1.0 .
podman run -d --name techmind-api -p 8000:8000 techmind-api:1.0
curl http://localhost:8000/health
```

## Evidencia esperada para la demo
- Captura del bucket con modelos cargados.
- Captura de instancia OCI Compute activa.
- Captura de `/docs` de FastAPI funcionando.
- Captura de respuesta JSON de `/contenido`.
