# TechMind MVP - Organización Inteligente del Conocimiento Técnico

## Objetivo
API MVP para clasificar, enriquecer y recomendar contenidos técnicos. Retorna JSON con categoría macro, categoría detallada, probabilidad, palabras clave y contenidos relacionados.

## Dataset
- Archivo: `data/Base_Contenido_1000_Registros_Reales_Categorias.xlsx`
- Registros originales: 10000
- Registros usados para modelado: 9997
- Categorías macro: 10
- Categorías detalladas: 17

## Pipeline de Ciencia de Datos
1. Carga de Excel.
2. Limpieza de texto y eliminación de HTML.
3. Construcción de `texto_modelo` con título, descripción y materias.
4. Vectorización TF-IDF con unigramas y bigramas.
5. Entrenamiento de dos modelos Logistic Regression.
6. Extracción de palabras clave por pesos TF-IDF.
7. Recomendación por similitud coseno.
8. Serialización con joblib.

## Métricas
### Categoría macro
- Accuracy: 0.9720
- Precision macro: 0.9419
- Recall macro: 0.9257
- F1 macro: 0.9324

### Categoría detallada NLP
- Accuracy: 0.9660
- Precision macro: 0.9194
- Recall macro: 0.9266
- F1 macro: 0.9203

Ver detalle en `docs/metricas_modelo.json`.

## Ejecutar localmente
```bash
pip install -r requirements.txt
cd api
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Abrir documentación:
```text
http://localhost:8000/docs
```

## Endpoints
### GET /health
Verifica estado de API.

### POST /contenido
Entrada:
```json
{"titulo":"Análisis de datos con Pandas","texto":"Limpieza y visualización de datos tabulares con Python.","top_k":5}
```

### POST /recomendar
Retorna contenidos relacionados por similitud textual.

## Docker
```bash
docker build -t techmind-api:1.0 .
docker run -p 8000:8000 techmind-api:1.0
```

## Integración OCI
Usar OCI Object Storage para modelos y dataset, y OCI Compute para desplegar la API. Ver `docs/EVIDENCIA_OCI.md`.

## Ejemplos
Ver `examples/ejemplos_uso.json` y `examples/curl_ejemplos.md`.
