# Ejemplos curl

```bash
curl -X GET http://localhost:8000/health

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"APIs REST con FastAPI","texto":"Curso práctico para crear servicios REST usando Python, FastAPI, validaciones y documentación automática.","top_k":3}'

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"Análisis de datos con Pandas","texto":"Introducción al procesamiento de datos tabulares, limpieza, agregaciones y visualización en Python.","top_k":3}'

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"Automatización de pruebas de penetración","texto":"Uso de Python para análisis de vulnerabilidades, escaneo de red y pruebas de seguridad.","top_k":3}'
```
