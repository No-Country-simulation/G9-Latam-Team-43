import os, re, json, textwrap, zipfile, shutil, warnings, sys
from pathlib import Path
warnings.filterwarnings('ignore')
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report
import joblib

base_dir = Path('/mnt/data')
excel_path = base_dir / 'Base_Contenido_1000_Registros_Reales_Categorias.xlsx'
project_dir = base_dir / 'techmind_mvp_entregables'
if project_dir.exists(): shutil.rmtree(project_dir)
for d in ['data','notebooks','models','api','docs','examples']:
    (project_dir/d).mkdir(parents=True, exist_ok=True)
shutil.copy2(excel_path, project_dir/'data'/excel_path.name)

def limpiar_texto(x):
    if pd.isna(x): return ''
    x = str(x)
    x = re.sub(r'<[^>]+>', ' ', x)
    x = re.sub(r'_x000D_|\n|\r|\t', ' ', x)
    x = re.sub(r'http\S+|www\.\S+', ' ', x)
    x = re.sub(r'[^\w\s\-\+\#\.áéíóúüñÁÉÍÓÚÜÑ]', ' ', x)
    return re.sub(r'\s+', ' ', x).strip()

df = pd.read_excel(excel_path, sheet_name='Sheet1', engine='openpyxl')
expected_cols = ['titulo','autores','editorial','isbn','anio_publicacion','descripcion','idioma','materias','url_openlibrary','categoria_nlp','categoria_macro']
df['texto_modelo'] = (df['titulo'].fillna('').map(limpiar_texto)+' '+df['descripcion'].fillna('').map(limpiar_texto)+' '+df['materias'].fillna('').map(limpiar_texto)).str.strip()
model_df = df[(df['texto_modelo'].str.len()>3) & df['categoria_macro'].notna() & df['categoria_nlp'].notna()].copy()

spanish_stop = set(['de','la','el','y','en','con','para','por','del','los','las','un','una','a','se','que','es','al','su','sus','como','using','with','and','for','the','of','to'])
stop_words = list(ENGLISH_STOP_WORDS.union(spanish_stop))
vectorizer_params = dict(max_features=30000, ngram_range=(1,2), min_df=2, stop_words=stop_words, sublinear_tf=True)
clf_params = dict(max_iter=1500, class_weight='balanced', solver='liblinear')
X = model_df['texto_modelo'].astype(str)
y_macro = model_df['categoria_macro'].astype(str)
y_nlp = model_df['categoria_nlp'].astype(str)
X_train, X_test, y_macro_train, y_macro_test, y_nlp_train, y_nlp_test = train_test_split(X, y_macro, y_nlp, test_size=0.2, random_state=42, stratify=y_macro)
modelo_macro = Pipeline([('tfidf', TfidfVectorizer(**vectorizer_params)), ('clf', LogisticRegression(**clf_params))])
modelo_nlp = Pipeline([('tfidf', TfidfVectorizer(**vectorizer_params)), ('clf', LogisticRegression(**clf_params))])
modelo_macro.fit(X_train, y_macro_train)
modelo_nlp.fit(X_train, y_nlp_train)
pred_macro = modelo_macro.predict(X_test)
pred_nlp = modelo_nlp.predict(X_test)
metrics = {
 'dataset': {'registros_originales': int(len(df)), 'registros_modelo': int(len(model_df)), 'columnas': expected_cols, 'categorias_macro': int(y_macro.nunique()), 'categorias_detalladas': int(y_nlp.nunique())},
 'modelo_macro': {'accuracy': float(accuracy_score(y_macro_test,pred_macro)), 'precision_macro': float(precision_score(y_macro_test,pred_macro,average='macro',zero_division=0)), 'recall_macro': float(recall_score(y_macro_test,pred_macro,average='macro',zero_division=0)), 'f1_macro': float(f1_score(y_macro_test,pred_macro,average='macro',zero_division=0)), 'classification_report': classification_report(y_macro_test,pred_macro,zero_division=0)},
 'modelo_categoria_nlp': {'accuracy': float(accuracy_score(y_nlp_test,pred_nlp)), 'precision_macro': float(precision_score(y_nlp_test,pred_nlp,average='macro',zero_division=0)), 'recall_macro': float(recall_score(y_nlp_test,pred_nlp,average='macro',zero_division=0)), 'f1_macro': float(f1_score(y_nlp_test,pred_nlp,average='macro',zero_division=0)), 'classification_report': classification_report(y_nlp_test,pred_nlp,zero_division=0)}
}
recommender_vectorizer = TfidfVectorizer(**vectorizer_params)
recommender_matrix = recommender_vectorizer.fit_transform(model_df['texto_modelo'].astype(str))
base_contenidos = model_df[['titulo','autores','anio_publicacion','descripcion','url_openlibrary','categoria_nlp','categoria_macro','texto_modelo']].reset_index(drop=True)
for obj, name in [(modelo_macro,'modelo_categoria_macro.joblib'),(modelo_nlp,'modelo_categoria_nlp.joblib'),(recommender_vectorizer,'vectorizador_recomendador.joblib'),(recommender_matrix,'matriz_recomendador.joblib'),(base_contenidos,'base_contenidos.joblib')]:
    joblib.dump(obj, project_dir/'models'/name)
(project_dir/'docs'/'metricas_modelo.json').write_text(json.dumps(metrics, indent=2, ensure_ascii=False), encoding='utf-8')

# API files
(project_dir/'api'/'main.py').write_text(r'''from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schemas import ContenidoRequest, ContenidoResponse, Recomendacion
from model_service import TechMindModelService

app = FastAPI(title="TechMind Knowledge Classifier API", description="API REST para clasificar, enriquecer y recomendar contenidos técnicos.", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
service = TechMindModelService(models_dir="../models")

@app.get("/health")
def health():
    return {"status": "ok", "service": "TechMind API", "modelos_cargados": service.modelos_cargados()}

@app.post("/contenido", response_model=ContenidoResponse)
def procesar_contenido(payload: ContenidoRequest):
    if not payload.titulo.strip() and not payload.texto.strip():
        raise HTTPException(status_code=400, detail="Debe informar al menos titulo o texto.")
    return service.procesar(payload.titulo, payload.texto, top_k=payload.top_k)

@app.post("/recomendar", response_model=list[Recomendacion])
def recomendar(payload: ContenidoRequest):
    if not payload.titulo.strip() and not payload.texto.strip():
        raise HTTPException(status_code=400, detail="Debe informar al menos titulo o texto.")
    return service.recomendar(payload.titulo, payload.texto, top_k=payload.top_k)
''', encoding='utf-8')
(project_dir/'api'/'schemas.py').write_text(r'''from pydantic import BaseModel, Field
from typing import List, Optional

class ContenidoRequest(BaseModel):
    titulo: str = Field(default="", description="Título del contenido técnico")
    texto: str = Field(default="", description="Texto, resumen o descripción del contenido")
    top_k: int = Field(default=5, ge=1, le=10, description="Cantidad de contenidos relacionados a retornar")

class Recomendacion(BaseModel):
    titulo: str
    autores: Optional[str] = None
    anio_publicacion: Optional[str] = None
    categoria_macro: str
    categoria_detallada: str
    similitud: float
    url_openlibrary: Optional[str] = None

class ContenidoResponse(BaseModel):
    categoria_macro: str
    categoria_detallada: str
    probabilidad_macro: float
    probabilidad_detallada: float
    palabras_clave: List[str]
    contenidos_relacionados: List[Recomendacion]
''', encoding='utf-8')
(project_dir/'api'/'model_service.py').write_text(r'''import re
from pathlib import Path
from typing import List, Dict, Any
import joblib
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def limpiar_texto(texto: str) -> str:
    texto = texto or ""
    texto = re.sub(r"<[^>]+>", " ", texto)
    texto = re.sub(r"_x000D_|\n|\r|\t", " ", texto)
    texto = re.sub(r"http\S+|www\.\S+", " ", texto)
    texto = re.sub(r"[^\w\s\-\+\#\.áéíóúüñÁÉÍÓÚÜÑ]", " ", texto)
    return re.sub(r"\s+", " ", texto).strip()

class TechMindModelService:
    def __init__(self, models_dir: str = "../models"):
        self.models_dir = Path(__file__).resolve().parent / models_dir
        self.modelo_macro = joblib.load(self.models_dir / "modelo_categoria_macro.joblib")
        self.modelo_nlp = joblib.load(self.models_dir / "modelo_categoria_nlp.joblib")
        self.vectorizador = joblib.load(self.models_dir / "vectorizador_recomendador.joblib")
        self.matriz = joblib.load(self.models_dir / "matriz_recomendador.joblib")
        self.base = joblib.load(self.models_dir / "base_contenidos.joblib")
    def modelos_cargados(self) -> bool:
        return all([self.modelo_macro is not None, self.modelo_nlp is not None, self.vectorizador is not None, self.matriz is not None, self.base is not None])
    def _texto(self, titulo: str, texto: str) -> str:
        return limpiar_texto(f"{titulo} {texto}")
    def _probabilidad(self, modelo, texto: str, clase: str) -> float:
        probs = modelo.predict_proba([texto])[0]
        clases = list(modelo.named_steps["clf"].classes_)
        return float(probs[clases.index(clase)])
    def extraer_palabras_clave(self, texto: str, top_n: int = 8) -> List[str]:
        vector = self.vectorizador.transform([texto])
        if vector.nnz == 0: return []
        feature_names = np.array(self.vectorizador.get_feature_names_out())
        scores = vector.toarray()[0]
        keywords = []
        for idx in scores.argsort()[::-1]:
            if scores[idx] <= 0: break
            termino = feature_names[idx]
            if len(termino) > 2 and termino not in keywords:
                keywords.append(termino)
            if len(keywords) >= top_n: break
        return keywords
    def recomendar(self, titulo: str, texto: str, top_k: int = 5) -> List[Dict[str, Any]]:
        contenido = self._texto(titulo, texto)
        vector = self.vectorizador.transform([contenido])
        sims = cosine_similarity(vector, self.matriz).ravel()
        idxs = sims.argsort()[::-1][:top_k]
        salida = []
        for idx in idxs:
            row = self.base.iloc[int(idx)]
            salida.append({"titulo": str(row.get("titulo", "")), "autores": None if str(row.get("autores", "")).lower()=="nan" else str(row.get("autores", "")), "anio_publicacion": None if str(row.get("anio_publicacion", "")).lower()=="nan" else str(row.get("anio_publicacion", "")), "categoria_macro": str(row.get("categoria_macro", "")), "categoria_detallada": str(row.get("categoria_nlp", "")), "similitud": round(float(sims[idx]), 4), "url_openlibrary": None if str(row.get("url_openlibrary", "")).lower()=="nan" else str(row.get("url_openlibrary", ""))})
        return salida
    def procesar(self, titulo: str, texto: str, top_k: int = 5) -> Dict[str, Any]:
        contenido = self._texto(titulo, texto)
        categoria_macro = self.modelo_macro.predict([contenido])[0]
        categoria_nlp = self.modelo_nlp.predict([contenido])[0]
        return {"categoria_macro": str(categoria_macro), "categoria_detallada": str(categoria_nlp), "probabilidad_macro": round(self._probabilidad(self.modelo_macro, contenido, categoria_macro), 4), "probabilidad_detallada": round(self._probabilidad(self.modelo_nlp, contenido, categoria_nlp), 4), "palabras_clave": self.extraer_palabras_clave(contenido), "contenidos_relacionados": self.recomendar(titulo, texto, top_k=top_k)}
''', encoding='utf-8')

(project_dir/'requirements.txt').write_text('''fastapi==0.111.0
uvicorn[standard]==0.30.1
pandas==2.2.2
openpyxl==3.1.5
scikit-learn==1.5.1
joblib==1.4.2
numpy==1.26.4
pydantic==2.8.2
python-multipart==0.0.9
''', encoding='utf-8')
(project_dir/'Dockerfile').write_text('''FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt /app/requirements.txt
RUN pip install --no-cache-dir -r requirements.txt
COPY api /app/api
COPY models /app/models
WORKDIR /app/api
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
''', encoding='utf-8')

# docs and README
readme = f'''# TechMind MVP - Organización Inteligente del Conocimiento Técnico

## Objetivo
API MVP para clasificar, enriquecer y recomendar contenidos técnicos. Retorna JSON con categoría macro, categoría detallada, probabilidad, palabras clave y contenidos relacionados.

## Dataset
- Archivo: `data/Base_Contenido_1000_Registros_Reales_Categorias.xlsx`
- Registros originales: {metrics['dataset']['registros_originales']}
- Registros usados para modelado: {metrics['dataset']['registros_modelo']}
- Categorías macro: {metrics['dataset']['categorias_macro']}
- Categorías detalladas: {metrics['dataset']['categorias_detalladas']}

## Pipeline de Ciencia de Datos
1. Carga de Excel.
2. Limpieza de texto y eliminación de HTML.
3. Construcción de `texto_modelo` con título, descripción y materias.
4. Vectorización TF-IDF con unigramas y bigramas.
5. Entrenamiento de dos modelos Logistic Regression.
6. Extracción de palabras clave por pesos TF-IDF.
7. Recomendación por similitud coseno.
8. Serialización con joblib.

## Métricas
### Categoría macro
- Accuracy: {metrics['modelo_macro']['accuracy']:.4f}
- Precision macro: {metrics['modelo_macro']['precision_macro']:.4f}
- Recall macro: {metrics['modelo_macro']['recall_macro']:.4f}
- F1 macro: {metrics['modelo_macro']['f1_macro']:.4f}

### Categoría detallada NLP
- Accuracy: {metrics['modelo_categoria_nlp']['accuracy']:.4f}
- Precision macro: {metrics['modelo_categoria_nlp']['precision_macro']:.4f}
- Recall macro: {metrics['modelo_categoria_nlp']['recall_macro']:.4f}
- F1 macro: {metrics['modelo_categoria_nlp']['f1_macro']:.4f}

Ver detalle en `docs/metricas_modelo.json`.

## Ejecutar localmente
```bash
pip install -r requirements.txt
cd api
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Abrir documentación:
```text
http://localhost:8000/docs
```

## Endpoints
### GET /health
Verifica estado de API.

### POST /contenido
Entrada:
```json
{{"titulo":"Análisis de datos con Pandas","texto":"Limpieza y visualización de datos tabulares con Python.","top_k":5}}
```

### POST /recomendar
Retorna contenidos relacionados por similitud textual.

## Docker
```bash
docker build -t techmind-api:1.0 .
docker run -p 8000:8000 techmind-api:1.0
```

## Integración OCI
Usar OCI Object Storage para modelos y dataset, y OCI Compute para desplegar la API. Ver `docs/EVIDENCIA_OCI.md`.

## Ejemplos
Ver `examples/ejemplos_uso.json` y `examples/curl_ejemplos.md`.
'''
(project_dir/'README.md').write_text(readme, encoding='utf-8')
(project_dir/'docs'/'EVIDENCIA_OCI.md').write_text('''# Evidencia técnica de integración OCI

## Servicios OCI usados
1. OCI Object Storage para almacenar artefactos `.joblib` y dataset.
2. OCI Compute para desplegar la API FastAPI.

## Comandos de referencia
```bash
oci os object put --bucket-name techmind-models --file models/modelo_categoria_macro.joblib
oci os object put --bucket-name techmind-models --file models/modelo_categoria_nlp.joblib
oci os object put --bucket-name techmind-models --file models/vectorizador_recomendador.joblib
oci os object put --bucket-name techmind-models --file models/matriz_recomendador.joblib
oci os object put --bucket-name techmind-models --file models/base_contenidos.joblib

podman build -t techmind-api:1.0 .
podman run -d --name techmind-api -p 8000:8000 techmind-api:1.0
curl http://localhost:8000/health
```

## Evidencia esperada para la demo
- Captura del bucket con modelos cargados.
- Captura de instancia OCI Compute activa.
- Captura de `/docs` de FastAPI funcionando.
- Captura de respuesta JSON de `/contenido`.
''', encoding='utf-8')

# Notebook minimal
nb={'cells':[],'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3.11'}},'nbformat':4,'nbformat_minor':5}
def md(s): nb['cells'].append({'cell_type':'markdown','metadata':{},'source':textwrap.dedent(s).strip().splitlines(True)})
def code(s): nb['cells'].append({'cell_type':'code','execution_count':None,'metadata':{},'outputs':[],'source':textwrap.dedent(s).strip().splitlines(True)})
md('# TechMind - Notebook de Ciencia de Datos\n\nEDA, limpieza, entrenamiento, evaluación, recomendación y serialización del MVP.')
code('''import pandas as pd, re, joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.metrics.pairwise import cosine_similarity''')
code('''df = pd.read_excel('../data/Base_Contenido_1000_Registros_Reales_Categorias.xlsx', sheet_name='Sheet1', engine='openpyxl')
df.shape, df.head()''')
code('''df['categoria_macro'].value_counts(), df['categoria_nlp'].value_counts().head(20)''')
code('''def limpiar_texto(x):
    if pd.isna(x): return ''
    x = re.sub(r'<[^>]+>', ' ', str(x))
    x = re.sub(r'_x000D_|\\n|\\r|\\t', ' ', x)
    x = re.sub(r'http\\S+|www\\.\\S+', ' ', x)
    x = re.sub(r'[^\\w\\s\\-\\+\\#\\.áéíóúüñÁÉÍÓÚÜÑ]', ' ', x)
    return re.sub(r'\\s+', ' ', x).strip()

df['texto_modelo'] = (df['titulo'].fillna('').map(limpiar_texto)+' '+df['descripcion'].fillna('').map(limpiar_texto)+' '+df['materias'].fillna('').map(limpiar_texto)).str.strip()
model_df = df[(df['texto_modelo'].str.len()>3) & df['categoria_macro'].notna() & df['categoria_nlp'].notna()].copy()
model_df.shape''')
code('''spanish_stop = set(['de','la','el','y','en','con','para','por','del','los','las','un','una','a','se','que','es','al','su','sus','como'])
stop_words = list(ENGLISH_STOP_WORDS.union(spanish_stop))
X = model_df['texto_modelo'].astype(str); y_macro = model_df['categoria_macro'].astype(str); y_nlp = model_df['categoria_nlp'].astype(str)
X_train, X_test, y_macro_train, y_macro_test, y_nlp_train, y_nlp_test = train_test_split(X, y_macro, y_nlp, test_size=0.2, random_state=42, stratify=y_macro)
params = dict(max_features=30000, ngram_range=(1,2), min_df=2, stop_words=stop_words, sublinear_tf=True)
clf = dict(max_iter=1500, class_weight='balanced', solver='liblinear')
modelo_macro = Pipeline([('tfidf', TfidfVectorizer(**params)), ('clf', LogisticRegression(**clf))])
modelo_nlp = Pipeline([('tfidf', TfidfVectorizer(**params)), ('clf', LogisticRegression(**clf))])
modelo_macro.fit(X_train, y_macro_train); modelo_nlp.fit(X_train, y_nlp_train)''')
code('''print('Macro accuracy:', accuracy_score(y_macro_test, modelo_macro.predict(X_test)))
print(classification_report(y_macro_test, modelo_macro.predict(X_test), zero_division=0))
print('NLP accuracy:', accuracy_score(y_nlp_test, modelo_nlp.predict(X_test)))
print(classification_report(y_nlp_test, modelo_nlp.predict(X_test), zero_division=0))''')
code('''vectorizador_recomendador = TfidfVectorizer(**params)
matriz_recomendador = vectorizador_recomendador.fit_transform(model_df['texto_modelo'].astype(str))
def recomendar(titulo, texto, top_k=5):
    vector = vectorizador_recomendador.transform([limpiar_texto(f'{titulo} {texto}')])
    sims = cosine_similarity(vector, matriz_recomendador).ravel()
    idxs = sims.argsort()[::-1][:top_k]
    return model_df.iloc[idxs][['titulo','autores','categoria_macro','categoria_nlp']].assign(similitud=sims[idxs])
recomendar('Análisis de datos con Pandas', 'Limpieza y visualización de datos tabulares con Python', 5)''')
code('''MODELS_DIR = Path('../models'); MODELS_DIR.mkdir(exist_ok=True)
base_contenidos = model_df[['titulo','autores','anio_publicacion','descripcion','url_openlibrary','categoria_nlp','categoria_macro','texto_modelo']].reset_index(drop=True)
joblib.dump(modelo_macro, MODELS_DIR/'modelo_categoria_macro.joblib')
joblib.dump(modelo_nlp, MODELS_DIR/'modelo_categoria_nlp.joblib')
joblib.dump(vectorizador_recomendador, MODELS_DIR/'vectorizador_recomendador.joblib')
joblib.dump(matriz_recomendador, MODELS_DIR/'matriz_recomendador.joblib')
joblib.dump(base_contenidos, MODELS_DIR/'base_contenidos.joblib')''')
(project_dir/'notebooks'/'01_entrenamiento_modelo.ipynb').write_text(json.dumps(nb, indent=2, ensure_ascii=False), encoding='utf-8')

# Copy runnable train as py
(project_dir/'notebooks'/'train_model.py').write_text(Path('/mnt/data/generate_techmind_deliverables.py').read_text(encoding='utf-8'), encoding='utf-8')

# Generate example responses using API service
sys.path.insert(0, str(project_dir/'api'))
from model_service import TechMindModelService
svc = TechMindModelService(models_dir='../models')
examples = {
 'ejemplo_backend_fastapi': {'request': {'titulo':'APIs REST con FastAPI','texto':'Curso práctico para crear servicios REST usando Python, FastAPI, validaciones y documentación automática.','top_k':3}},
 'ejemplo_ciencia_datos': {'request': {'titulo':'Análisis de datos con Pandas','texto':'Introducción al procesamiento de datos tabulares, limpieza, agregaciones y visualización en Python.','top_k':3}},
 'ejemplo_ciberseguridad': {'request': {'titulo':'Automatización de pruebas de penetración','texto':'Uso de Python para análisis de vulnerabilidades, escaneo de red y pruebas de seguridad.','top_k':3}}
}
for v in examples.values():
    r = v['request']; v['response_generada'] = svc.procesar(r['titulo'], r['texto'], r['top_k'])
(project_dir/'examples'/'ejemplos_uso.json').write_text(json.dumps(examples, indent=2, ensure_ascii=False), encoding='utf-8')
(project_dir/'examples'/'curl_ejemplos.md').write_text('''# Ejemplos curl

```bash
curl -X GET http://localhost:8000/health

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"APIs REST con FastAPI","texto":"Curso práctico para crear servicios REST usando Python, FastAPI, validaciones y documentación automática.","top_k":3}'

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"Análisis de datos con Pandas","texto":"Introducción al procesamiento de datos tabulares, limpieza, agregaciones y visualización en Python.","top_k":3}'

curl -X POST http://localhost:8000/contenido -H "Content-Type: application/json" -d '{"titulo":"Automatización de pruebas de penetración","texto":"Uso de Python para análisis de vulnerabilidades, escaneo de red y pruebas de seguridad.","top_k":3}'
```
''', encoding='utf-8')

manifest=[]
for file in project_dir.rglob('*'):
    if file.is_file(): manifest.append({'archivo':str(file.relative_to(project_dir)), 'tamano_kb':round(file.stat().st_size/1024,2)})
(project_dir/'MANIFEST.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
zip_path = base_dir/'TechMind_MVP_Entregables.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for file in project_dir.rglob('*'):
        z.write(file, arcname=str(file.relative_to(project_dir.parent)))
print(json.dumps({'zip': str(zip_path), 'zip_size_mb': round(zip_path.stat().st_size/1024/1024,2), 'total_files': len(manifest), 'metricas': {'macro_accuracy': metrics['modelo_macro']['accuracy'], 'nlp_accuracy': metrics['modelo_categoria_nlp']['accuracy']}, 'manifest': manifest}, indent=2, ensure_ascii=False))
