from pydantic import BaseModel, Field
from typing import List, Optional

class ContenidoRequest(BaseModel):
    titulo: str = Field(default="", description="Título del contenido técnico")
    texto: str = Field(default="", description="Texto, resumen o descripción del contenido")
    top_k: int = Field(default=5, ge=1, le=10, description="Cantidad de contenidos relacionados a retornar")

class Recomendacion(BaseModel):
    titulo: str
    autores: Optional[str] = None
    anio_publicacion: Optional[str] = None
    categoria_macro: str
    categoria_detallada: str
    similitud: float
    url_openlibrary: Optional[str] = None

class ContenidoResponse(BaseModel):
    categoria_macro: str
    categoria_detallada: str
    probabilidad_macro: float
    probabilidad_detallada: float
    palabras_clave: List[str]
    contenidos_relacionados: List[Recomendacion]
