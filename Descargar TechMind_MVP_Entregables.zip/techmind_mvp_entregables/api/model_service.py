import re
from pathlib import Path
from typing import List, Dict, Any
import joblib
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

def limpiar_texto(texto: str) -> str:
    texto = texto or ""
    texto = re.sub(r"<[^>]+>", " ", texto)
    texto = re.sub(r"_x000D_|\n|\r|\t", " ", texto)
    texto = re.sub(r"http\S+|www\.\S+", " ", texto)
    texto = re.sub(r"[^\w\s\-\+\#\.áéíóúüñÁÉÍÓÚÜÑ]", " ", texto)
    return re.sub(r"\s+", " ", texto).strip()

class TechMindModelService:
    def __init__(self, models_dir: str = "../models"):
        self.models_dir = Path(__file__).resolve().parent / models_dir
        self.modelo_macro = joblib.load(self.models_dir / "modelo_categoria_macro.joblib")
        self.modelo_nlp = joblib.load(self.models_dir / "modelo_categoria_nlp.joblib")
        self.vectorizador = joblib.load(self.models_dir / "vectorizador_recomendador.joblib")
        self.matriz = joblib.load(self.models_dir / "matriz_recomendador.joblib")
        self.base = joblib.load(self.models_dir / "base_contenidos.joblib")
    def modelos_cargados(self) -> bool:
        return all([self.modelo_macro is not None, self.modelo_nlp is not None, self.vectorizador is not None, self.matriz is not None, self.base is not None])
    def _texto(self, titulo: str, texto: str) -> str:
        return limpiar_texto(f"{titulo} {texto}")
    def _probabilidad(self, modelo, texto: str, clase: str) -> float:
        probs = modelo.predict_proba([texto])[0]
        clases = list(modelo.named_steps["clf"].classes_)
        return float(probs[clases.index(clase)])
    def extraer_palabras_clave(self, texto: str, top_n: int = 8) -> List[str]:
        vector = self.vectorizador.transform([texto])
        if vector.nnz == 0: return []
        feature_names = np.array(self.vectorizador.get_feature_names_out())
        scores = vector.toarray()[0]
        keywords = []
        for idx in scores.argsort()[::-1]:
            if scores[idx] <= 0: break
            termino = feature_names[idx]
            if len(termino) > 2 and termino not in keywords:
                keywords.append(termino)
            if len(keywords) >= top_n: break
        return keywords
    def recomendar(self, titulo: str, texto: str, top_k: int = 5) -> List[Dict[str, Any]]:
        contenido = self._texto(titulo, texto)
        vector = self.vectorizador.transform([contenido])
        sims = cosine_similarity(vector, self.matriz).ravel()
        idxs = sims.argsort()[::-1][:top_k]
        salida = []
        for idx in idxs:
            row = self.base.iloc[int(idx)]
            salida.append({"titulo": str(row.get("titulo", "")), "autores": None if str(row.get("autores", "")).lower()=="nan" else str(row.get("autores", "")), "anio_publicacion": None if str(row.get("anio_publicacion", "")).lower()=="nan" else str(row.get("anio_publicacion", "")), "categoria_macro": str(row.get("categoria_macro", "")), "categoria_detallada": str(row.get("categoria_nlp", "")), "similitud": round(float(sims[idx]), 4), "url_openlibrary": None if str(row.get("url_openlibrary", "")).lower()=="nan" else str(row.get("url_openlibrary", ""))})
        return salida
    def procesar(self, titulo: str, texto: str, top_k: int = 5) -> Dict[str, Any]:
        contenido = self._texto(titulo, texto)
        categoria_macro = self.modelo_macro.predict([contenido])[0]
        categoria_nlp = self.modelo_nlp.predict([contenido])[0]
        return {"categoria_macro": str(categoria_macro), "categoria_detallada": str(categoria_nlp), "probabilidad_macro": round(self._probabilidad(self.modelo_macro, contenido, categoria_macro), 4), "probabilidad_detallada": round(self._probabilidad(self.modelo_nlp, contenido, categoria_nlp), 4), "palabras_clave": self.extraer_palabras_clave(contenido), "contenidos_relacionados": self.recomendar(titulo, texto, top_k=top_k)}
