from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from schemas import ContenidoRequest, ContenidoResponse, Recomendacion
from model_service import TechMindModelService

app = FastAPI(title="TechMind Knowledge Classifier API", description="API REST para clasificar, enriquecer y recomendar contenidos técnicos.", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
service = TechMindModelService(models_dir="../models")

@app.get("/health")
def health():
    return {"status": "ok", "service": "TechMind API", "modelos_cargados": service.modelos_cargados()}

@app.post("/contenido", response_model=ContenidoResponse)
def procesar_contenido(payload: ContenidoRequest):
    if not payload.titulo.strip() and not payload.texto.strip():
        raise HTTPException(status_code=400, detail="Debe informar al menos titulo o texto.")
    return service.procesar(payload.titulo, payload.texto, top_k=payload.top_k)

@app.post("/recomendar", response_model=list[Recomendacion])
def recomendar(payload: ContenidoRequest):
    if not payload.titulo.strip() and not payload.texto.strip():
        raise HTTPException(status_code=400, detail="Debe informar al menos titulo o texto.")
    return service.recomendar(payload.titulo, payload.texto, top_k=payload.top_k)
